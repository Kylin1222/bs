const path = require("path");
const fs = require("fs-extra");
const { marked } = require("marked");
const port = 9999; // 端口号
const hostName = "172.16.227.130"; //代理服务器主机名
const myhttp = require("http"); //服务器-浏览器交互遵循http协议，导入http模块，此为node自带
var url = require("url");
var querystring = require("querystring");
const staticPath = "./mds";

marked.setOptions({
  renderer: new marked.Renderer(),
  gfm: true,
  tables: true,
  breaks: false,
  pedantic: false,
  sanitize: false,
  smartLists: true,
  smartypants: false,
  highlight: function (code, lang) {
    const hljs = require("highlight.js");
    const language = hljs.getLanguage(lang) ? lang : "plaintext";
    return hljs.highlight(code, { language }).value;
  },
  langPrefix: "hljs language-",
});

const server = myhttp.createServer(async (req, res) => {
  // 设置请求头，解决跨域
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "X-Rquested-With");
  res.setHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.setHeader("X-Powered-By", "3.2.1");
  res.setHeader("Content-Type", "application/json;charset=utf-8");

  switch (req.url.split("?")[0]) {
    case "/md":
      //获取返回的url对象的query属性值
      let arg = url.parse(req.url).query;
      //将arg参数字符串反序列化为一个对象
      let params = querystring.parse(arg);

      let md = "";
      try {
        md = await fs.readFile(
          path.join(staticPath, `${params.id}.md`),
          "utf-8"
        );
      } catch (error) {
        console.log(error);
      } finally {
        res.end(
          JSON.stringify({
            code: md ? 200 : -1,
            data: marked(md),
            msg: md ? "成功" : "没有找到对应文章",
          })
        );
      }
      break;
  }
});

server.listen(port, hostName, function () {
  console.log(`server running.... at ${hostName}:${port}`);
});
